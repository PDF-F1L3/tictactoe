﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Parreno_TicTacToe.Models;  // Import the GameState class

public class IndexModel : PageModel
{
    private static GameState _gameState = new GameState();
    public GameState GameState => _gameState;

    // Handles the GET request
    public void OnGet()
    {
        // Load the current game state if needed
    }

    private (int, int) MakeAIMove()
    {
        Random rand = new Random();
        int row, col;

        do
        {
            row = rand.Next(0, 3);
            col = rand.Next(0, 3);
        } while (_gameState.Board[row, col] != '-');

        return (row, col);
    }

    // Handles the player's move
    public JsonResult OnPostMakeMove(int row, int col)
    {
        if (_gameState.Board[row, col] == '-')
        {
            _gameState.Board[row, col] = _gameState.IsPlayerTurn ? 'X' : 'O';
            _gameState.IsPlayerTurn = !_gameState.IsPlayerTurn;

            // Check for game over condition
            string gameStatus = CheckGameStatus();
            if (gameStatus != "Game in Progress")
            {
                _gameState.Status = gameStatus;
                return new JsonResult(new { status = gameStatus });
            }

            // If AI is playing, make AI's move
            if (!_gameState.IsPlayerTurn && _gameState.IsAIPlaying)
            {
                var aiMove = MakeAIMove();
                _gameState.Board[aiMove.Item1, aiMove.Item2] = 'O';
                _gameState.IsPlayerTurn = !_gameState.IsPlayerTurn;
                gameStatus = CheckGameStatus();
                return new JsonResult(new { status = gameStatus });
            }
        }

        return new JsonResult(new { status = "Game in Progress" });
    }

    // Handles restarting the game
    public JsonResult OnPostRestartGame()
    {
        _gameState.ResetBoard();
        return new JsonResult(new { status = "Game in Progress" });
    }

    // Handles switching between AI and Player mode
    public JsonResult OnPostSwitchMode()
    {
        _gameState.IsAIPlaying = !_gameState.IsAIPlaying;
        return new JsonResult(new { status = "Game in Progress" });
    }
    public string CheckGameStatus()
    {
        // Check for winning conditions in rows, columns, or diagonals
        for (int i = 0; i < 3; i++)
        {
            // Check rows
            if (_gameState.Board[i, 0] == _gameState.Board[i, 1] && _gameState.Board[i, 1] == _gameState.Board[i, 2] && _gameState.Board[i, 0] != '-')
                return _gameState.Board[i, 0] == 'X' ? "Player X Wins!" : "Player O Wins!";

            // Check columns
            if (_gameState.Board[0, i] == _gameState.Board[1, i] && _gameState.Board[1, i] == _gameState.Board[2, i] && _gameState.Board[0, i] != '-')
                return _gameState.Board[0, i] == 'X' ? "Player X Wins!" : "Player O Wins!";
        }

        // Check diagonals
        if (_gameState.Board[0, 0] == _gameState.Board[1, 1] && _gameState.Board[1, 1] == _gameState.Board[2, 2] && _gameState.Board[0, 0] != '-')
            return _gameState.Board[0, 0] == 'X' ? "Player X Wins!" : "Player O Wins!";

        if (_gameState.Board[0, 2] == _gameState.Board[1, 1] && _gameState.Board[1, 1] == _gameState.Board[2, 0] && _gameState.Board[0, 2] != '-')
            return _gameState.Board[0, 2] == 'X' ? "Player X Wins!" : "Player O Wins!";

        // Check for draw (if board is full and no winner)
        bool isFull = true;
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if (_gameState.Board[i, j] == '-')
                {
                    isFull = false;
                    break;
                }
            }
        }

        if (isFull)
            return "Draw";

        // If no winner and game isn't full, it's still in progress
        return "Game in Progress";
    }



}

