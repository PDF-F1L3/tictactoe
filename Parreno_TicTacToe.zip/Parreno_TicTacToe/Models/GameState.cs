﻿namespace Parreno_TicTacToe.Models
{
    public class GameState
    {
        public char[,] Board { get; set; } = new char[3, 3];
        public bool IsPlayerTurn { get; set; } = true;  // true if player's turn, false if AI's turn
        public bool IsAIPlaying { get; set; } = true;  // true for Player vs AI, false for Player vs Player
        public string Status { get; set; } = "Game in Progress";

        public GameState()
        {
            ResetBoard();
        }

        public void ResetBoard()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Board[i, j] = '-';
                }
            }
            Status = "Game in Progress";
        }
    }

}
