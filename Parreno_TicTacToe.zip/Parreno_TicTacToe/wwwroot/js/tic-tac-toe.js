﻿$(function () {
    // Event handler for game cells
    $('.game-cell').on('click', function () {
        console.log('Cell clicked');
        if ($('#game-status').text() !== '') return; // Prevent clicks if game is over

        var row = $(this).data('row');
        var col = $(this).data('col');

        $.post('/?handler=MakeMove', { row: row, col: col }, function (response) {
            console.log('Server response:', response);
            if (response.status !== "Game in Progress") {
                $('#game-status').text(response.status);
            }
            updateBoard();
        });
    });

    // Event handler for restart button
    $('#restart-btn').on('click', function () {
        $.post('/?handler=RestartGame', function (response) {
            updateBoard();
            $('#game-status').text('');
        });
    });

    // Event handler for mode toggle button
    $('#mode-toggle-btn').on('click', function () {
        $.post('/?handler=SwitchMode', function (response) {
            updateBoard();
        });
    });

    // Function to update the game board
    function updateBoard() {
        $.get('/Game/GetBoardState', function (data) {
            for (let i = 0; i < 3; i++) {
                for (let j = 0; j < 3; j++) {
                    $('#cell-' + (i * 3 + j)).text(data.Board[i][j]);
                }
            }
        });
    }
});